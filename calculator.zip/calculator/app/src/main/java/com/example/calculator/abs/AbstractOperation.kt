package com.example.calculator.abs

abstract class AbstractOperation {
    abstract fun operate(num1: Int, num2: Int): Double
}