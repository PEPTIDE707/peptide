package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

//class MainActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//    }
//}


fun main(){

    println("수식을 입력 해 주세요 : ")

    class Calculator{
        var num1 = readLine()!!.toDouble()
        var operator = readLine().toString()
        var num2 = readLine()!!.toDouble()
        var result = 0.0.toDouble()

        fun operator(){
            when(operator){
                "+" -> {
                    result = num1 + num2
                    println("+ :  ${result} ")
                }
                "-" ->{
                    result = num1 - num2
                    println("- :  ${result} ")
                }
                "%" ->{
                    result = num1 % num2
                    println("% :  ${result} ")
                }
                "*" ->{
                    result = num1 * num2
                    println("* :  ${result} ")
                }
                else -> println("다시 입력 해 주세요.")
            }
        }
    }
}